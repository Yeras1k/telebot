<?php
session_start();
include_once("connection.php");

?>

<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <title>Hello, world!</title>
	<link href="css/style.css" rel="stylesheet">
	<link rel="manifest" href="manifest.json">
	
	
  </head>
  <body>
  
  <header>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="https://upload.wikimedia.org/wikipedia/commons/7/7f/IELTS_logo.svg" width="100"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">IELTS materials</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
       
      </ul>
	  <?php
		if(!empty($_SESSION)):
			if ($_SESSION["auth"]==true):
			$sql = "SELECT * FROM Users WHERE uID=".$_SESSION['uid'];
			$r = mysqli_query($conn, $sql);
			$userData = mysqli_fetch_assoc($r);						
	  ?>
	  <form action="logout.php" method="POST">
	  <div class="row">	  
	  <p class="col"><?=$userData["Firstname"]." ".$userData["Surname"]?></p>
	  <button class="col btn btn-outline-success me-3" type="submit">Logout</button>
	  </div>
	  </form>
	  <?php endif; else: ?>	 	  
      <button class="btn btn-outline-success me-3" type="submit" data-bs-toggle="modal" data-bs-target="#login" >Sign in</button>
	  <button class="btn btn-outline-success" type="submit" data-bs-toggle="modal" data-bs-target="#signup" >Sign up</button>
	  <?php endif; ?>
    </div>
  </div>
</nav>

<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://ak.picdn.net/shutterstock/videos/4507700/thumb/6.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://st2.depositphotos.com/1017986/8720/i/950/depositphotos_87200076-stock-photo-group-of-happy-students-showing.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://bccie.bc.ca/wp-content/uploads/2020/05/IDP-Research-Thumbnail.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

</header>
<main>

	<div class="container">
		<section id="aboutme">
			<h1 align="center">ABOUT ME</h1>
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-12">
					<img src="https://professional-education.online/wp-content/uploads/2020/06/How-to-get-a-job-as-a-teacher.jpeg" width="100%">
				</div>
				<div class="col-lg-8 col-md-8 col-sm-12">
					<p>Hello, my name is ... </p>
				</div>
			</div>
		</section>
		
		<section id="achivements">
			<h1 align="center">ACHIVEMENTS</h1>
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-12">
					<img class="py-3" src="https://thumbs.dreamstime.com/b/business-success-goals-corporate-strategy-to-succeed-as-financial-wealth-concept-pathway-profit-d-illustration-elements-172925190.jpg" width="100%">
				</div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<img class="py-3" src="https://w7.pngwing.com/pngs/934/325/png-transparent-guarantee-warranty-business-customer-service-warranty-emblem-text-label.png" width="100%">
				</div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<img class="py-3" src="https://amd-russia.com/wp-content/uploads/quality-stamp.png" width="100%">
				</div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<img class="py-3" src="https://constructorus.ru/wp-content/uploads/2010/12/%D0%A7%D1%82%D0%BE-%D1%82%D0%B0%D0%BA%D0%BE%D0%B5-%D1%83%D1%81%D0%BF%D0%B5%D1%85.jpg" width="100%">
				</div>
				
			</div>
		</section>
		
		<section id="price">
			<h1 align="center">PRICE PLAN</h1>
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="card">
						<br>
					  <h2 align="center">Online</h2>
					  <br>
					  <ul>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
					  </ul>
					  <br>
					  
					  <div class="card-body" style="background: green; color: white">
						<p class="card-text"><h2 align="center">2500₸</h2></p>
					  </div>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="card">
						<br>
					  <h2 align="center">Combine</h2>
					  <br>
					  <ul>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
					  </ul>
					  <br>
					  
					  <div class="card-body" style="background: green; color: white">
						<p class="card-text"><h2 align="center">4000₸</h2></p>
					  </div>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="card">
						<br>
					  <h2 align="center">Offline</h2>
					  <br>
					  <ul>
						<li>Face-to-face</li>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
						<li>Zoom</li>
					  </ul>
					  <br>
					  
					  <div class="card-body" style="background: green; color: white">
						<p class="card-text"><h2 align="center">5000₸</h2></p>
					  </div>
					</div>
				</div>
				
			</div>
		</section>
		
		<section id="booking">
			<h1 align="center">BOOKING</h1>
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12">
					<img class="py-3" src="https://thumbs.dreamstime.com/b/business-success-goals-corporate-strategy-to-succeed-as-financial-wealth-concept-pathway-profit-d-illustration-elements-172925190.jpg" width="100%">
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12">
					
<form>
  <div class="mb-3">
    <label for="user_name" class="form-label">Your name</label>
    <input type="text" class="form-control" id="user_name" placeholder="Enter your name">    
  </div>
  <div class="mb-3">
    <label for="user_phone" class="form-label">Phone number</label>
    <input type="text" class="form-control" id="user_phone" placeholder="+77471305430">    
  </div>
  <div class="mb-3">
    <label for="user_email" class="form-label">Your email</label>
    <input type="email" class="form-control" id="user_email" placeholder="Enter email">    
  </div>
  <div class="mb-3">
    <label for="user_date" class="form-label">Date</label>
    <input type="date" class="form-control" id="user_date">    
  </div>
  
  <select class="form-select mb-3">
	<option>Online</option>
	<option>Conbine</option>
	<option>Offline</option>
  </select>
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
					
				</div>
				
				
			</div>
		</section>
		
	</div>
</main>
<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-12">
				<p>Contact</p>
				<ul>
					<li><a href="tel:+77471305430">+77471305430</a> </li>
					<li><a href="mailto:zhunusovem@mail.ru">zhunusovem@mail.ru</a></li>					
				</ul>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12">
				<p>Support</p>
				<ul>
					<li>+7 747 13054304</li>
					<li>+7 747 13054304</li>					
				</ul>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12">
				<p>About us</p>
				<ul>
					<li><a href="">History</a></li>
					<li><a href="">Achivments</a></li>					
				</ul>
			</div>
		</div>
		<div class="row my-3">
			<div class="col-lg-4 col-md-4 col-sm-12">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
  <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
</svg>

<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
  <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
</svg>

<a href="https://wa.me/87471305430">
<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16">
  <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/>
</svg>
</a>

			</div>
		</div>
		<div class="row mt-3">
			<div class="col text-center">
				<p>&copy; Petropavl 2022</p>
			</div>
		</div>
		
	</div>
</footer>
	
	 
   
	
    <script src="js/bootstrap.bundle.min.js" ></script>
	<script src="js/main.js"></script>
	<script src="sw.js"></script>
	
	
	<div class="modal" id="login" tabindex="-1" aria-labelledby="login" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title">Sign in form</h5>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		  </div>
		  <div class="modal-body">
			<form action="signin.php" method="POST">
				<div class="mb-3">
					<label for="email" class="form-label">Your email</label>
					<input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>
				</div>
				<div class="mb-3">
					<label for="pass" class="form-label">Your password</label>
					<input type="password" id="pass" name="pass" class="form-control" placeholder="Enter your password" required>
				</div>
				<div class="mb-3">
				<button type="submit" class="btn btn-primary" >Sign in</button>
				</div>
			</form>
		  </div>
		  
		</div>
	  </div>
	</div>
	
	<div class="modal" id="signup" tabindex="-1" aria-labelledby="signup" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title">Sign up form</h5>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		  </div>
		  <div class="modal-body">
			<form action="signup.php" method="POST" onsubmit="return true">
				<p id="errorMsg"></p>
				<div class="mb-3">
					<label for="fname" class="form-label">Your firstname</label>
					<input type="text" id="fname" name="fname" class="form-control" placeholder="Enter your firstname" required>
				</div>
				<div class="mb-3">
					<label for="lname" class="form-label">Your lastname</label>
					<input type="text" id="lname" name="lname" class="form-control" placeholder="Enter your lastname" required>
				</div>
				<div class="mb-3">
					<label for="email" class="form-label">Your email</label>
					<input type="email" id="email" name="email" class="form-control" placeholder="Enter your email"  required>
				</div>
				<div class="mb-3">
					<label for="pass" class="form-label">Your password</label>
					<input type="password" id="pass" name="pass" class="form-control" placeholder="Enter your password" required>
				</div>
				<div class="mb-3">
					<label for="confirmpass" class="form-label">Confirm password</label>
					<input type="password" id="confirmpass" name="confirmpass" class="form-control" placeholder="Confirm your password" required>
				</div>
				<div class="mb-3">
				<button type="submit" class="btn btn-primary" >Sign up</button>
				</div>
			</form>
		  </div>
		  
		</div>
	  </div>
	</div>
	
  </body>
</html>