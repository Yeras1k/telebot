//alert("Hello Adil")

function checkForm(){
	pass = document.querySelector("#pass").value
	confirmpass = document.querySelector("#confirmpass").value
	console.log(pass,confirmpass)
	return false
}