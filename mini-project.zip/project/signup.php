<?php
include_once("connection.php");

$fname = $_POST["fname"];
$lname = $_POST["lname"];
$email = $_POST["email"];
$pass = $_POST["pass"];



$sql = "INSERT INTO Users (uID, Firstname, Surname, rID, `E-mail`, Password, DataOfRegistration) VALUES (NULL, '$fname', '$lname', 2, '$email' , '$pass', current_timestamp())";
$result = mysqli_query($conn, $sql);

header("Location: index.php");

?>