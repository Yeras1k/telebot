<?php
session_start();
$email = $_POST["email"];
$pass = $_POST["pass"];

include_once("connection.php");

$sql = "SELECT * FROM Users WHERE `E-mail`='$email'";

$result = mysqli_query($conn, $sql);
$res = mysqli_fetch_assoc($result);

$userPassword = $res["Password"];

if($pass==$userPassword){
	$_SESSION["auth"]=true;
	$_SESSION["uid"]=$res["uID"];	
}else{
	$_SESSION["auth"]=false;
}

header("Location: index.php");
?>